Altapay - PHP SDK
=================

== Change log ==

** Version 1.0.1

    * Bugfix: PensioCallbackHandler - xml body response without Transaction element

** Version 1.0.0

    * Set the base for the version number

** Version 0.1.0

    * New child element [PaymentSource] in Transaction

** Version 0.0.1

    * Created the change log 