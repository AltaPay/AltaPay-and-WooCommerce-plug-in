<?php
/**
 * The template for displaying altapay payment form
 * @package Altapay
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
get_header();
//$altapay = new WC_Gateway_Altapay();
?>

<div id="primary" class="content-area">
    <main id="main" class="site-main" role="main">
        <h3 id="order_review_heading"><?php _e( 'Your order (ID: '. esc_html($_POST['shop_orderid']).')', 'woocommerce' ); ?></h3>
        <div id="order_review" class="woocommerce-checkout-review-order">
			<?php do_action( 'altapay_checkout_order_review' ); ?>
        </div>
        <form id="PensioPaymentForm"></form>
    </main>
</div>

<?php
get_sidebar();
get_footer();
?>
