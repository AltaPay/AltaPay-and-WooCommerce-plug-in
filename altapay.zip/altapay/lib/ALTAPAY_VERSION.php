<?php
// This file is auto-generated... do not edit by hand
define('ALTAPAY_VERSION', 'PHPSDK/20150427');