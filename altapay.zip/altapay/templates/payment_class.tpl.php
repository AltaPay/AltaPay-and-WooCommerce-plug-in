<?php

class WC_Gateway_{key} extends WC_Payment_Gateway {
		use AltapayMaster;
		
		public function __construct() {		
			// Set default gateway values
			$this->id = strtolower('altapay_{key}');
			$this->icon = ''; // Url to image
			$this->has_fields = false;
			$this->method_title = 'AltaPay - {name}';
			$this->method_description = __( 'Adds AltaPay Payment Gateway to use with WooCommerce', 'altapay');
			$this->supports = array(
				'refunds',
				'subscriptions',
				'subscription_cancellation',
				'subscription_suspension',
				'subscription_reactivation',
				'subscription_amount_changes',
				'subscription_date_changes',
			);
			
			$this->terminal = '{name}';
			$this->enabled = $this->get_option( 'enabled' );
			$this->title = $this->get_option( 'title' );
			$this->description = $this->get_option( 'description' );
			$this->payment_action = $this->get_option( 'payment_action' );
			$this->currency = $this->get_option( 'currency' );
			$currency = explode(' ', '{name}');
			$this->default_currency = end($currency);

			// Load form fields
			$this->init_form_fields();
			$this->init_settings();
			
			// Add actions
			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
			add_action( 'woocommerce_receipt_' . $this->id, array( $this, 'receipt_page_altapay' ) );			
			add_action( 'woocommerce_api_wc_gateway_' . $this->id, array( $this, 'check_altapay_response' ) );
	
			// Subscription actions
			add_action( 'woocommerce_scheduled_subscription_payment_altapay', array($this, 'scheduled_subscription_payment'), 10, 2 );					
		}
		
		public function admin_options() {
			echo '<h3>{name}</h3>';
			echo '<table class="form-table">';
            $this->generate_settings_html();
			echo '</table>';	
		}
		
		public function receipt_page_altapay( $order_id ) {
			// Show text
			echo '<p>'.__('You are now going to be redirected to AltaPay Payment Gateway','altapay').'</p>';		
			$redirectURL = $this->createPaymentRequest( $order_id );
			echo '<script type="text/javascript">window.location.href = "'.$redirectURL.'"</script>';
		}
		
		public function createPaymentRequest( $order_id ) {	
			global $wpdb;
			// Create form request etc.
			$api = $this->api_login();
			
			// Create payment request
			$order = new WC_Order( $order_id );
			
			// TODO Get terminal form instance
			$terminal = $this->terminal;
			
			$amount = $order->order_total;
			$currency = $order->get_order_currency(); //get_woocommerce_currency();
			$customer_info = array(
				'billing_firstname' => $order->billing_first_name,
				'billing_lastname' => $order->billing_last_name,
				'billing_address' => $order->billing_address_1,
				'billing_postal' => $order->billing_postcode,
				'billing_city' => $order->billing_city,
				'billing_region' => $order->billing_state,
				'billing_country' => $order->billing_country,
				'email' => $order->billing_email,
				'shipping_firstname' => $order->shipping_first_name,
				'shipping_lastname' => $order->shipping_last_name,
				'shipping_address' => $order->shipping_address_1,
				'shipping_postal' => $order->shipping_postcode,
				'shipping_city' => $order->shipping_city,
				'shipping_region' => $order->shipping_state,
				'shipping_country' => $order->shipping_country,
			);
			
			$cookie = isset($_SERVER['HTTP_COOKIE']) ? $_SERVER['HTTP_COOKIE'] : '';
			$language = 'en';
			
			$languages = array('da_DK' => 'da', 'sv_SE' => 'sv', 'nn_NO' => 'no', 'de_DE' => 'de');
			if ($languages[get_locale()]) {
				$language = $languages[get_locale()];
			}
			
			// Get chosen page from altapay settings
			$form_page_id = esc_attr( get_option('altapay_payment_page') );
			$config = array(
				'callback_form' => get_page_link($form_page_id), 
				'callback_ok' => add_query_arg( 'wc-api', 'WC_Gateway_'.$this->id, $this->get_return_url($order) ),
				'callback_fail' => add_query_arg( 'wc-api', 'WC_Gateway_'.$this->id, $this->get_return_url($order) ), //add_query_arg( 'wc-api', 'WC_Gateway_'.$this->id, $order->get_cancel_order_url() ),
			);
			
			// Make these as settings
			$payment_type = 'payment';
			if ($this->payment_action == 'authorize_capture') {
				$payment_type = 'paymentAndCapture';
			}
			
			// Check if WooCommerce subscriptions is enabled
			if (class_exists( 'WC_Subscriptions_Order' )) {
				// Check if cart containt subscription product
				if( WC_Subscriptions_Order::order_contains_subscription( $order_id ) ) {
					if ($this->payment_action == 'authorize_capture') {
						$payment_type = 'subscriptionAndCharge';
					} else {
						$payment_type = 'subscriptionAndReserve';
					}
				}
			}
			
			// Add orderlines to altapay request
			$orderlines = $order->get_items();
			$linedata = array();
			foreach ($orderlines as $orderline_key => $orderline) {
				// TODO Maybe use product_id?
				
				$_product = get_product($orderline['product_id']);
				$sku = $_product->get_sku();
				$variation_id = $orderline['variation_id'];

		        if ($variation_id) {
		            $result = $wpdb->get_results("SELECT meta_value FROM $wpdb->postmeta WHERE meta_key = '_sku' AND post_id = '" . $variation_id . "'");
		            if ($result[0]->meta_value) {
		                $sku = $result[0]->meta_value;
		            }
		        }
				
				$linedata[] = array(
					'description' => $orderline['name'],
					'itemId' => $sku,
					'quantity' => $orderline['qty'],
					'unitPrice' => (float) number_format($orderline['line_subtotal'] / $orderline['qty'], 2, '.', ''),
					'taxAmount' => (float) number_format($orderline['line_tax'] / $orderline['qty'], 2, '.', ''),
				);								
			}

			$response = $api->createPaymentRequest($terminal, $order_id, $amount, $currency, $payment_type, $customer_info, $cookie, $language, $config, array(), $linedata);
			
			if( !$response->wasSuccessful() ) {
				return new WP_Error( 'error', 'Could not create the payment request' );
			}

			$redirectURL = $response->getRedirectURL();
			
			return $redirectURL;
		}
		
		public function check_altapay_response() {	
			// Check if callback is altapay and the allowed IP
			if ( $_GET['wc-api'] == 'WC_Gateway_'.$this->id /*&& $_SERVER['REMOTE_ADDR'] == '77.66.40.133'*/ ) {
				global $woocommerce;
				$postdata = $_POST;
				
				$order_id = $postdata['shop_orderid'];
			 	$order = new WC_Order($order_id);
			 	$txnid = $postdata['transaction_id'];
			 	$cardno = $postdata['masked_credit_card'];
			 	$amount = $postdata['amount'];
			 	$credtoken = $postdata['credit_card_token'];
			 	$error_message = $postdata['error_message'];
				$merchant_error_message = $postdata['merchant_error_message'];
				$status = $postdata['payment_status'];
			 	
			 	if ($status == 'released') {
			 		$order->add_order_note( __('Payment failed: payment released', 'Altapay') ); 
					wc_add_notice( __('Payment error:', 'altapay') . ' Payment released', 'error' );
					$cart_url = $woocommerce->cart->get_cart_url();
					wp_redirect($cart_url);
					//$redirect = $order->get_cancel_order_url();
					//wp_redirect($redirect);				
					exit;
			 	}
			 	
			 	if ($_GET['cancel_order']) {
					$order->add_order_note( __('Payment failed: ' . $error_message .' Merchant error: ' . $merchant_error_message, 'Altapay') ); 
					wc_add_notice( __('Payment error:', 'altapay') . ' '.$error_message, 'error' );
					$cart_url = $woocommerce->cart->get_cart_url();
					wp_redirect($cart_url);
					//$redirect = $order->get_cancel_order_url();
					//wp_redirect($redirect);				
					exit;
				}
			 	
			 	// Make some validation			 	
			 	if ($postdata['error_message'] || $postdata['merchant_error_message']) {
			 		$order->add_order_note( __('Payment failed: ' . $error_message .' Merchant error: ' . $merchant_error_message, 'Altapay') ); 
					wc_add_notice( __('Payment error:', 'altapay') . ' '.$error_message, 'error' );
					$cart_url = $woocommerce->cart->get_cart_url();
					wp_redirect($cart_url);
					//$redirect = $order->get_cancel_order_url();
					//wp_redirect($redirect);					
					exit;
			 	}
			 				 	
			 	if( $order->has_status('pending') ) {
					// Payment completed
					$order->add_order_note(__('Callback completed', 'Altapay'));                
					$order->payment_complete();
				
					update_post_meta($order_id, '_transaction_id', $txnid);
					update_post_meta($order_id, '_cardno', $cardno);
					update_post_meta($order_id, '_credit_card_token', $credtoken);
				}
				
				// Redirect to Accept page
				$redirect = $this->get_return_url($order);
				wp_redirect($redirect);
				exit;
			}
		}		
		
}
